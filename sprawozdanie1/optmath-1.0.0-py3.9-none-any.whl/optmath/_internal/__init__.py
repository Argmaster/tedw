from .interface import PyRectangle
