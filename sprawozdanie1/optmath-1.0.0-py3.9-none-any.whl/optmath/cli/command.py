import click


@click.command()
def command():
    pass
