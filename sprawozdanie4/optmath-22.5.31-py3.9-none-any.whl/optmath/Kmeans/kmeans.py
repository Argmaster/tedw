from dataclasses import dataclass
from functools import lru_cache
from hashlib import sha1
from inspect import isclass
from typing import Callable, Generator, Optional, Tuple, Type, TypeVar, Union
from matplotlib.axes import Axes

import numpy as np
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from numpy.typing import NDArray
from rich.progress import Progress

from optmath import RecordBase
from optmath.HCA.distance import DistanceBase, Euclidean

GroupedT = Tuple[Tuple[RecordBase, ...]]
EndConditionFuncT = Callable[[GroupedT, GroupedT], bool]


def Kmeans(
    autoscaled_data: Tuple[RecordBase, ...],
    cluster_count: Optional[int] = None,
    iter_limit: int = 50,
    distance: Union[DistanceBase, Type[DistanceBase]] = Euclidean,
    active_end_condition: Optional[EndConditionFuncT] = None,
) -> "KmeansResultView":

    if isclass(distance):
        distance = distance()
    assert isinstance(distance, DistanceBase)

    assert iter_limit > 0
    assert len(autoscaled_data) > 0
    record_class = autoscaled_data[0].__class__

    if cluster_count is None:
        cluster_count = int(np.ceil(np.log(np.sqrt(len(autoscaled_data)))))

    centers = _random_sample(autoscaled_data, cluster_count)
    groups: Optional[GroupedT] = None

    with Progress() as progress:
        task = progress.add_task("Clustering...", total=iter_limit)
        _iteration_index = 0

        for _iteration_index in range(iter_limit):
            distance_matrix = _get_distances_matrix(
                autoscaled_data, distance, centers
            )
            # matrix format
            # __________| pc1   | pc2   | ...
            # object 1  |       |       |
            new_clusters = _get_new_clusters(
                autoscaled_data, centers, distance_matrix
            )
            # check optional end condition.
            if (
                groups is not None
                and active_end_condition is not None
                and active_end_condition(groups, new_clusters)
            ):
                break

            new_centers = _get_new_centers(
                autoscaled_data, record_class, new_clusters
            )

            centers = new_centers
            groups = new_clusters
            progress.update(task, advance=1)
        progress.update(
            task,
            total=iter_limit,
            description=f"Finished after {_iteration_index} iterations.",
        )
    assert groups is not None
    return KmeansResultView(groups)


def _get_new_centers(
    autoscaled_data: Tuple[RecordBase, ...],
    record_class: Type[RecordBase],
    new_clusters: Tuple[Tuple[RecordBase, ...]],
) -> Tuple[RecordBase, ...]:
    new_centers = []
    for cluster_index, cluster in enumerate(new_clusters):
        missing = len(cluster[0].columns()) - len(cluster[0].numeric()) - 1
        numeric_obs = np.array([ob.numeric() for ob in cluster])
        new_center = record_class(
            len(autoscaled_data) + cluster_index,
            *np.mean(numeric_obs, axis=0),
            *(None for _ in range(missing)),
        )
        new_centers.append(new_center)
    return tuple(new_centers)


def _get_new_clusters(
    autoscaled_data: Tuple[RecordBase, ...],
    centers: Tuple[RecordBase, ...],
    distance_matrix: NDArray[np.float64],
) -> Tuple[Tuple[RecordBase, ...]]:
    return tuple(
        tuple(
            ob
            for ob, min_id in zip(
                autoscaled_data,
                np.argmin(distance_matrix, axis=1),
            )
            if min_id == group_id
        )
        for group_id, _ in enumerate(centers)
    )


def _get_distances_matrix(
    autoscaled_data: Tuple[RecordBase, ...],
    distance: DistanceBase,
    centers: Tuple[RecordBase, ...],
) -> NDArray[np.float64]:
    return np.array(
        [
            [distance(ob, center) for center in centers]
            for ob in autoscaled_data
        ]
    )


_T = TypeVar("_T")


def _random_sample(data: Tuple[_T], cluster_count: int) -> Tuple[_T, ...]:
    rand_index = np.random.uniform(0, len(data), cluster_count)
    return tuple(data[np.int64(index)] for index in rand_index)


@dataclass
class KmeansResultView:

    clusters: Tuple[Tuple[RecordBase, ...]]

    def linear(self) -> Generator[Tuple[int, RecordBase], None, None]:
        for i, cluster in enumerate(self.clusters):
            for ob in cluster:
                yield (i, ob)

    def plot_clusters(
        self, size: Tuple[int, int] = (22, 22), dpi: int = 80
    ):  # noqa: CCR001
        n = len(self.clusters[0][0].columns()) - 1
        fig, ax = plt.subplots(n, n)

        fig.set_size_inches(size)
        fig.set_dpi(dpi)

        assert len(self.clusters)
        assert len(self.clusters[0])

        for i, column1 in enumerate(self.clusters[0][0].columns()[1:]):
            for j, column2 in enumerate(self.clusters[0][0].columns()[1:]):
                axes = ax[i][j]  # type: ignore
                assert isinstance(axes, Axes)

                for k, cluster in enumerate(self.clusters):
                    xs = [ob[column1] for ob in cluster]
                    ys = [ob[column2] for ob in cluster]
                    axes.scatter(xs, ys, c=colors(k))

                axes.set_xlabel(column1)
                axes.set_ylabel(column2)


@lru_cache(32)
def colors(n: int):
    return f'#{sha1(str(n).encode("utf-8")).hexdigest()[:6]}99'
