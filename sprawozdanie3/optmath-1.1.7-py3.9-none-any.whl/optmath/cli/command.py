import click


@click.command()
def command() -> None:
    pass
